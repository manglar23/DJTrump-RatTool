import sys
from notoken887.encryptor import TokenCryptor

def obf():
    if len(sys.argv) != 3:
        print("Error: Please provide both input and output file names.")
        return

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    c = TokenCryptor()

    with open(input_file, 'r', encoding='utf-8') as infile:
        code = infile.readlines()

    import_lines = [line for line in code if line.strip().startswith(("from", "import"))]
    code_lines = [line for line in code if not line.strip().startswith(("from", "import"))]

    hex_code = ''.join([f'{ord(c):02x}' for c in ''.join(code_lines)])
    yhsgeіkzh = c.proccess(hex_code)

    exec_code = f"""
{''.join(import_lines)}    
from notoken887.encryptor import TokenCryptor
def print(*args, **kwargs): pass
c = TokenCryptor()
yhsgeіkzh = '{yhsgeіkzh}'
yhsgeikzh = c.process(yhsgeіkzh)
exec(bytes.fromhex(yhsgeikzh).decode('utf-8'))
"""

    with open(output_file, 'w', encoding='utf-8') as outfile:
        outfile.write(exec_code)
obf()