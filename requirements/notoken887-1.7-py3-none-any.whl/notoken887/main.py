import argparse
import os
import random as FRUYFRUYHFRYUHFRYHUFRYUH, string as PAOPOEUNZNZIIOOQINNNZBBAYWVAVABUYNBNNZNZNVBVBVWEVYATVIBZOBWIZBVCQTAIQKNZGYEIUIUZNAKEUYFB87we4e8ws74qw984z84th7es8qa7tg874eds74tr8, builtins as FUIFRU56194965148948749498ergerfr
iufr = FUIFRU56194965148948749498ergerfr.print
from notoken887.encryptor import TokenCryptor as EUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbiaEUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbia

def main():
    def encrypt_code(code, imports):
        cryptor = EUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbiaEUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbia()
        encrypted_lines = []
        for line in code.splitlines():
            if line.strip().startswith('import') or line.strip().startswith('from'):
                imports.append(line)
            else:
                encrypted_lines.append(cryptor.proccess(line))
        return '\n'.join(encrypted_lines)

    def remove_comments(code):
        return '\n'.join([line for line in code.splitlines() if not line.strip().startswith('#')])

    def process_file(input_path, output_path, mode):
        input_path = os.path.abspath(input_path)
        output_path = os.path.abspath(output_path)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(input_path, 'r', encoding='utf-8') as infile:
            content = infile.read()

        imports = []
        if mode == 'e':
            encrypted_code = encrypt_code(content, imports)
            l_string = f"'''{encrypted_code.replace('\\n', ' ')}'''"
            imports_code = ';'.join(imports)
            main_pyw_content = f"{imports_code}\ndef print(*args, **kwargs): iufr(''.join(FRUYFRUYHFRYUHFRYHUFRYUH.choices(PAOPOEUNZNZIIOOQINNNZBBAYWVAVABUYNBNNZNZNVBVBVWEVYATVIBZOBWIZBVCQTAIQKNZGYEIUIUZNAKEUYFB87we4e8ws74qw984z84th7es8qa7tg874eds74tr8.ascii_letters + PAOPOEUNZNZIIOOQINNNZBBAYWVAVABUYNBNNZNZNVBVBVWEVYATVIBZOBWIZBVCQTAIQKNZGYEIUIUZNAKEUYFB87we4e8ws74qw984z84th7es8qa7tg874eds74tr8.digits, k=FRUYFRUYHFRYUHFRYHUFRYUH.randint(600, 10000))))\nimport random as FRUYFRUYHFRYUHFRYHUFRYUH, string as PAOPOEUNZNZIIOOQINNNZBBAYWVAVABUYNBNNZNZNVBVBVWEVYATVIBZOBWIZBVCQTAIQKNZGYEIUIUZNAKEUYFB87we4e8ws74qw984z84th7es8qa7tg874eds74tr8, builtins as FUIFRU56194965148948749498ergerfr\niufr = FUIFRU56194965148948749498ergerfr.print\nfrom notoken887.encryptor import TokenCryptor as EUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbiaEUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbia\nIURFUIRFUIJRFIUJIOSOIASOIAFJNZNMMZMZUFUUEEIEIUAUIUIZUIIUJASEIUUFUFUYFHFYUHFIUFJIOFZOKOIAFUH = EUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbiaEUINISBIbiuewbiuewnbewiubfiuewbfiuewbfiuewbfiubeufbewiufbieuwfbiewbfefbwiunziunziuzbnwuvbqibwikjqbuyevuytzvuyqbwieuqbiuwvbqiuvqiuyvbaytgwHGViuywvbia()\nl = {l_string}\nHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIF458HJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIF784HJISOISNEINIUNEIUNEIUZMIF = IURFUIRFUIJRFIUJIOSOIASOIAFJNZNMMZMZUFUUEEIEIUAUIUIZUIIUJASEIUUFUFUYFHFYUHFIUFJIOFZOKOIAFUH.process(l)\nexec(HJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIF458HJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIFHJISOISNEINIUNEIUNEIUZMIF784HJISOISNEINIUNEIUNEIUZMIF)"
            output_content = remove_comments(main_pyw_content)
        else:
            decrypted_content = decrypt_code(content)
            output_content = remove_comments(decrypted_content.strip())

        with open(output_path, 'w', encoding='utf-8') as outfile:
            outfile.write(output_content)

    parser = argparse.ArgumentParser(description='Encrypt or decrypt Python files using TokenCryptor.')
    parser.add_argument('--input', '-i', type=str, required=True, help='Input file path')
    parser.add_argument('--output', '-o', type=str, required=True, help='Output file path')
    parser.add_argument('--mode', '-m', choices=['e'], required=True, help='Mode: e for encrypt')
    args = parser.parse_args()
    process_file(args.input, args.output, args.mode)
